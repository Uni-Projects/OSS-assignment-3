#!/bin/bash

FILE=/tmp/file
FILE2=/tmp/file2
echo 0 > $FILE

while :
do
	if test -f $FILE2; then
		if cmp $FILE $FILE2 >/dev/null 2>&1; then
			od -An -N2 -i /dev/random > $FILE
		fi
	fi
done
