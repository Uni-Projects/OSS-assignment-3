#!/bin/bash

FILE=/tmp/file
FILE2=/tmp/file2
echo 1 > $FILE2

while :
do 
	if test -f $FILE; then
		cat $FILE
		cat $FILE > $FILE2;
	fi
done
